"use client";
import { ActivityHistory } from "@/app/app/_components/ActivityHistory";

export default function FitnessHistoryPage() {
  return <ActivityHistory activityKey="workout" title="Fitness History" emoji="💪" />;
}
