"use client";
/** Page tints are now built into ThemeGate. This stub exists for import compatibility. */
export function PageTint() { return null; }
