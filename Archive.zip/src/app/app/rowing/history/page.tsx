"use client";

import { ActivityHistory } from "@/app/app/_components/ActivityHistory";

export default function RowingHistoryPage() {
  return <ActivityHistory title="Rowing" activityKey="rowing" emoji="🚣" />;
}
