import WidgetKit
import SwiftUI

@main
struct Routines365WidgetBundle: WidgetBundle {
    var body: some Widget {
        Routines365Widget()
    }
}
